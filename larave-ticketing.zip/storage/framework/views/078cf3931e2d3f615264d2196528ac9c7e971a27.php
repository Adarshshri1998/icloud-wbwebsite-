<?php $__env->startSection('title', 'Complaint Detail'); ?>
<?php $__env->startSection('content'); ?>
    <div class="validation-page">
        <div class="container text-center">
            <h2>Complaint Detail</h2>
            <p>
                All fields marked with an <b>asterisk (*)</b> are required</p>
        </div>

        <div class="row">
            <div class="col-sm-8 col-sm-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Register New Complaint</div>
                    <div class="panel-body">

                        <?php echo e(Form::open(['url'=>'departments', 'method' => 'post'])); ?>


                        <div class="form-group">
                            <label class="control-label">Department Name:</label>
                            <input type="text" class="form-control" name="name"/>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-success pull-right rounded">Add</button>
                        </div>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>