
<?php $__env->startSection('title', 'Staff List'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <section id="category-one">
            <div class="category-one">
                <div class="container">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                            <?php if(Session::has('message')): ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <strong>Alert!</strong> <?php echo e(Session::get('message')); ?>

                                </div>
                            <?php endif; ?>

                            <div class="table-section">
                                <div class="table-responsive">
                                    <table class="table table-lead user-table">
                                        <h3 class="title clearfix">Staff <span>List</span>
                                            <a href="<?php echo e(url('admin/staff/create')); ?>" class="pull-right">Add new</a>

                                        </h3>
                                        <thead>
                                        <tr>
                                            <th class="heading">Name</th>
                                            <th class="heading">Email</th>
                                            <th class="heading">Avatar</th>
                                            <th class="heading">Department</th>
                                            <th class="heading">Registered On</th>
                                            <th class="heading">Action</th>

                                        </tr>
                                        </thead>
                                        <tbody>

                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($user->hasRole('staff')): ?>
                                                <tr id="<?php echo e($user->id); ?>">
                                                    <td>
                                                        <a href="<?php echo e(url('admin/staff')); ?>/<?php echo e($user->id); ?>/edit">
                                                            <?php echo e($user->name); ?>

                                                        </a>
                                                    </td>
                                                    <td><?php echo e($user->email); ?></td>
                                                    <td>
                                                        <?php if($user->avatar ==  null): ?>
                                                            <img src="<?php echo e(asset('uploads')); ?>/avatar.png" alt="avatar" class="img-circle" style="height: 40px; width:40px">
                                                        <?php else: ?>
                                                            <img src="<?php echo e(asset('uploads')); ?>/<?php echo e($user->avatar); ?>" alt="avatar" class="img-circle" style="height: 40px; width:40px">

                                                        <?php endif; ?>
                                                    </td>

                                                    <td>
                                                        <?php if($user->department_id ==  null): ?>
                                                            No Department
                                                            <?php else: ?>
                                                            <?php echo e($user->departments->name); ?>



                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo e($user->created_at); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(url('admin/staff')); ?>/<?php echo e($user->id); ?>/edit" class="eye">
                                                            <i class="fa fa-pencil"></i></a>
                                                        <a href="#" class="eye delete-btn" data-id="<?php echo e($user->id); ?>">
                                                            <i class="fa fa-trash"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="pagination_links clearfix">
                                <?php echo e($users->links()); ?>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            $(document).on('click', '.delete-btn', function () {
                var id = $(this).attr('data-id');
                swal({
                        title: "Are you sure?",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: "Yes, delete it!",
                        cancelButtonText: "No, cancel!",
                        closeOnConfirm: false,
                        closeOnCancel: true
                    },
                    function(isConfirm){
                        if (isConfirm) {
                            $.ajax({
                                type: 'DELETE',
                                url: '<?php echo e(url('/admin/staff')); ?>'+"/"+id,
                                data:{
                                    id:id,
                                    '_token': '<?php echo e(csrf_token()); ?>'
                                },
                                success: function (data) {
                                    $('.user-table tr#'+id+'').hide();
                                    swal("Deleted!", "Staff has been deleted.", "success");

                                }
                            })
                        } else {
                            swal("Cancelled", "Staff is safe :)", "error");
                        }
                    });
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.tickets', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>