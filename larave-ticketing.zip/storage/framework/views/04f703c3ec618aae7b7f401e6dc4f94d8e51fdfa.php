<?php $__env->startSection('title', 'Admin Panel'); ?>
<?php $__env->startSection('content'); ?>
    <div class="validation-page">
        <div class="container-fluid text-left printarea">
            <h2>Complaint List</h2>
        </div>
        <br>
        <br>

        <div class="container-fluid">
            <div class="row Hide_Print_Area">
                <div class="col-sm-9 Print_Extended_Width">
                    <div class="panel panel-default with-button">
                        <div class="panel-heading clearfix">
                            <span>Complaints List</span>
                            <div class="header-button pull-right">
                                <a href="#" id="print" class="btn btn-primary rounded noMargin">Print Report</a>
                            </div>

                            <div class="header-button pull-right calendar dropdown">
                                <a href="javascript:;" data-toggle="dropdown" class="btn btn-primary rounded noMargin dropdown-toggle">Print Using Date Range</a>
                                <div class="dropdown-menu">

                                    <?php echo e(Form::open(['url'=>'/director-list'])); ?>

                                    <form action="">

                                        <div class="form-group">
                                            <label>Select Range</label>
                                            <input type="text" name="range" class="form-control range-picker">
                                        </div>

                                        <button type="submit" class="btn btn-success rounded pull-right">Go</button>
                                    </form>

                                </div>
                            </div>

                        </div>
                        <div class="panel-body">

                            <div class="alert custom-dark-alert-success printarea">
                                <strong>Date: </strong><span class="print-status date">
                <?php if( !empty ( $selection_date ) ): ?>
                                        <?php echo e($selection_date); ?>

                                    <?php else: ?>
                                        Not Selected
                                    <?php endif; ?>
            </span>
                            </div>
                            <div class="alert custom-dark-alert-success printarea">
                                <strong>Status: </strong><span class="print-status status">
                <?php if( !empty ( $status ) ): ?>
                                        <?php echo e($status); ?>

                                    <?php else: ?>
                                        All
                                    <?php endif; ?>
            </span>
                            </div>
                            <div class="alert custom-dark-alert-success printarea">
                                <strong>Assigned User: </strong><span class="print-status user">
                <?php if( !empty($assigned_user ) ): ?>
                                        <?php echo e($assigned_user->name); ?>

                                    <?php else: ?>
                                        All
                                    <?php endif; ?>
            </span>
                            </div>


                            <table class="table data-table table-bordered table-striped printarea">
                                <thead>
                                <tr>
                                    <th>Complainant Name</th>
                                    <th>Token No</th>
                                    <th>Email</th>
                                    <th>Mobile</th>
                                    <th>Status</th>
                                    <th>Complaint Logged</th>
                                    <th class="media-hidden">Action</th>
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                    <th>Complainant Name</th>
                                    <th>Token No</th>
                                    <th>Email</th>
                                    <th>Mobile</th>
                                    <th>Status</th>
                                    <th>Complaint Logged</th>
                                    <th class="media-hidden">Action</th>
                                </tr>
                                </tfoot>
                                <tbody>
                                <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="<?php echo e($items->status); ?>">
                                        <td><?php echo e($items->complainant_name); ?></td>
                                        <td><?php echo e($items->token); ?></td>
                                        <td><?php echo e($items->email); ?></td>
                                        <td><?php echo e($items->mobile); ?></td>
                                        <td class="text-capitalize"><?php echo e($items->status); ?></td>
                                        <td><?php echo e($items->created_at->format('d M Y')); ?></td>
                                        <td class="text-center media-hidden">
                                             <span data-toggle="tooltip" title="Comments">
                                                   <a target="_blank" href="<?php echo e(url('/complaint_comments', ['id'=>$items->id])); ?>" class="btn-xs btn btn-warning"><i class="fa fa-comment"></i> </a>
                                            </span>
                                            

                                            <span data-toggle="tooltip" title="View">
                                            <a  target="_blank" href="<?php echo e(url('/view-complaints', ['id'=>$items->id])); ?>" class="btn-xs btn btn-primary" value="<?php echo e($items->id); ?>"><i class="fa fa-eye"></i></a>

                                        </span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>


                        </div>
                    </div>
                </div>
                <div class="col-sm-3 Hide_Print_Area">
                    <div class="panel panel-default">
                        <div class="panel-heading ">Search Filter</div>
                        <div class="panel-body">
                            <?php echo e(Form::open(['url' => 'admin-search', 'class'=>'filter-form'])); ?>

                            <div class="form-group">
                                <label>Select Date</label>
                                <select name="date" class="form-control text-capitalize select_date">
                                    <?php if( !empty ( $selection_date ) ): ?>
                                        <option selected value="<?php echo e($selection_date); ?>"><?php echo e($selection_date); ?></option>
                                        <option value>select</option>
                                    <?php else: ?>
                                        <option selected value>select</option>
                                    <?php endif; ?>
                                    <option value="today">Today</option>
                                    <option value="yesterday">Yesterday</option>
                                    <option value="Last 7 Days">Last 7 Days</option>
                                    <option value="month">Last Month</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Issue Status</label>
                                <select name="status" class="form-control text-capitalize select_status">
                                    <?php if( !empty ( $status ) ): ?>
                                        <option selected value="<?php echo e($status); ?>"><?php echo e($status); ?></option>
                                        <option value>select</option>
                                    <?php else: ?>
                                        <option selected value>select</option>
                                    <?php endif; ?>
                                    <option value="open">Open</option>
                                    <option value="closed">Closed</option>
                                    <option value="over due">Over Due</option>
                                    <option value="under process">Under Process</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Users</label>
                                <select name="user" class="form-control text-capitalize select_user">
                                    <?php if( !empty($assigned_user ) ): ?>
                                        <option selected value="<?php echo e($assigned_user->id); ?>"><?php echo e($assigned_user->name); ?></option>
                                        <option value>select</option>

                                    <?php else: ?>
                                        <option selected value>select</option>
                                    <?php endif; ?>

                                    <?php $__currentLoopData = $directors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($items->id); ?>"><?php echo e($items->username); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group clearfix">
                                <button type="submit" class="btn btn-success pull-right rounded"> Search </button>
                            </div>

                            <?php echo e(Form::close()); ?>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $("#print").click(function () {
                window.print();
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>