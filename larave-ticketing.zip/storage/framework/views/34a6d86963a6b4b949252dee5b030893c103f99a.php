<?php $__env->startSection('title', 'Admin Panel'); ?>
<?php $__env->startSection('content'); ?>
    <div class="validation-page">
        <div class="container-fluid text-left printarea">
            <h2>Director List</h2>
        </div>
        <br>
        <br>

        <div class="container-fluid">
            <div class="row Hide_Print_Area">
                <div class="col-sm-8 Print_Extended_Width col-sm-offset-2">
                    <div class="panel panel-default with-button">
                        <div class="panel-heading clearfix">
                            <span>Complaints List</span>
                            <div class="header-button pull-right">
                                <a href="#" id="print" class="btn btn-primary rounded noMargin">Print Report</a>
                            </div>

                        </div>
                        <div class="panel-body">
                            <table class="table data-table table-bordered table-striped printarea">
                                <thead>
                                <tr>
                                    <th>Director Name</th>
                                    <th>Open Tickets</th>
                                    <th>Closed Tickets</th>
                                    <th>Overdue Tickets</th>
                                    <th>Under process</th>
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                    <th>Director Name</th>
                                    <th>Open Tickets</th>
                                    <th>Closed Tickets</th>
                                    <th>Overdue Tickets</th>
                                    <th>Under process</th>
                                </tr>
                                </tfoot>
                                <tbody>
                                <?php $__currentLoopData = $directors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $director): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($director->username); ?></td>
                                        <td>
                                            <?php $i=0 ?>
                                            <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <?php if($complaint->status == 'open' && $complaint->assign_to == $director->id): ?>
                                                    <?php $i++ ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo $i ?>

                                        </td>
                                        <td>
                                            <?php $i=0 ?>
                                            <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <?php if($complaint->status == 'closed' && $complaint->assign_to == $director->id): ?>
                                                    <?php $i++ ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo $i ?>
                                        </td>
                                        <td>
                                            <?php $i=0 ?>
                                            <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <?php if($complaint->status == 'over due' && $complaint->assign_to == $director->id): ?>
                                                    <?php $i++ ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo $i ?>
                                        </td>
                                        <td>
                                            <?php $i=0 ?>
                                            <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <?php if($complaint->status == 'under process' && $complaint->assign_to == $director->id): ?>
                                                    <?php $i++ ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo $i ?>
                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $("#print").click(function () {
                window.print();
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>