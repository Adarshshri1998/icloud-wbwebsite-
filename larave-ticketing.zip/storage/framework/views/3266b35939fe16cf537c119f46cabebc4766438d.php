<?php $__env->startSection('title', 'Focal Admin Panel'); ?>
<?php $__env->startSection('content'); ?>
    <div class="validation-page">
        <div class="container-fluid text-left">
            <h2>Complaint Color Codes</h2>
            <h5 class="Color_Code_Scheme"><b>Blue:</b> Open<br>
                <b>Green:</b> Under Process <br>
                <b>Yellow:</b> Closed<br>
                <b>Red:</b> Over Due
            </h5>

            <?php if(Session::has('success_message')): ?>
                <div class="alert custom-dark-alert-<?php echo e(Session::get('alert_class')); ?> alert-dismissible">
                    <button class="close" data-dismiss="alert"><span>×</span></button>
                    <bold><?php echo e(Session::get('success_message')); ?></bold>
                </div>
            <?php endif; ?>

            <?php if(Session::has('danger_message')): ?>
                <div class="alert custom-dark-alert-<?php echo e(Session::get('alert_class')); ?> alert-dismissible">
                    <button class="close" data-dismiss="alert"><span>×</span></button>
                    <strong>Success!</strong> <?php echo e(Session::get('danger_message')); ?>

                </div>
            <?php endif; ?>
        </div>
        <br>
        <br>
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-9">
                    <div class="panel panel-default with-button">
                        <div class="panel-heading clearfix">
                            <span>Complaints List</span>
                            <div class="header-button pull-right">
                                <a href="#" data-toggle="modal" data-target="#intimate" class="btn btn-primary rounded noMargin">Intimate the Complainant</a>
                            </div>
                            <div class="header-button pull-right calendar  dropdown">
                                <a href="javascript:;" data-toggle="dropdown" class="btn btn-primary rounded noMargin dropdown-toggle">Notification</a>
                                <div class="dropdown-menu notification">
                                    <ul class="list-unstyled">
                                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <?php if($comment->user_id != null): ?>
                                                <li>New comment added by <?php echo e($comment->users->username); ?> at <?php echo e($comment->created_at->toDateString()); ?><br>
                                                    Token #: <?php echo e($comment->complaints->token); ?>

                                                </li>
                                            <?php endif; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </ul>

                                </div>
                            </div>

                        </div>
                        <div class="panel-body">
                            <table class="table data-table table-bordered table-striped">
                                <thead>
                                <tr>
                                    <th>Complainant Name</th>
                                    <th>Token No</th>
                                    <th>Email</th>
                                    <th>Mobile No</th>
                                    <th>Intimate</th>
                                    <th>Status</th>
                                    <th>Complaint Logged</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                    <th>Complainant Name</th>
                                    <th>Token No</th>
                                    <th>Email</th>
                                    <th>Mobile</th>
                                    <th>Intimate</th>
                                    <th>Status</th>
                                    <th>Complaint Logged</th>
                                    <th>Action</th>
                                </tr>
                                </tfoot>
                                <tbody>
                                <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="<?php echo e($items->status); ?>">
                                        <td><?php echo e($items->complainant_name); ?></td>
                                        <td><?php echo e($items->token); ?></td>
                                        <td><?php echo e($items->email); ?></td>
                                        <td><?php echo e($items->mobile); ?></td>

                                        <td>
                                            <?php if($items->intimate == 'true'): ?>
                                                <span class="label label-success">Send</span>
                                            <?php else: ?>
                                                <span class="label label-danger">Not Yet</span>
                                            <?php endif; ?>

                                            </td>
                                        <td><?php echo e($items->status); ?></td>
                                        <td><?php echo e($items->created_at->format('d M Y')); ?></td>
                                        <td class="text-center">
                                             <span data-toggle="tooltip" title="Comments">
                                                   <a target="_blank" href="<?php echo e(url('/complaint_comments', ['id'=>$items->id])); ?>" class="btn-xs btn btn-warning"><i class="fa fa-comment"></i> </a>
                                            </span>
                                            <span data-toggle="tooltip" title="Edit">
                                                   <a target="_blank" href="<?php echo e(url('/edit-complaint', ['id'=>$items->id])); ?>" class="btn-xs btn btn-success"><i class="fa fa-pencil"></i> </a>
                                            </span>

                                            <span data-toggle="tooltip" title="View">
                                            <a target="_blank" href="<?php echo e(url('/view-complaints', ['id'=>$items->id])); ?>" class="btn-xs btn btn-primary" value="<?php echo e($items->id); ?>"><i class="fa fa-eye"></i></a>

                                        </span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="panel panel-default">
                        <div class="panel-heading">Search Filter</div>
                        <div class="panel-body">
                            <?php echo e(Form::open(['url' => 'search', 'class'=>'filter-form'])); ?>

                                <div class="form-group">
                                    <label>Select Date</label>
                                    <select name="date" class="form-control text-capitalize">
                                        <?php if( !empty ( $selection_date ) ): ?>
                                            <option selected value="<?php echo e($selection_date); ?>"><?php echo e($selection_date); ?></option>
                                            <option value>select</option>

                                        <?php else: ?>
                                            <option selected value>select</option>
                                        <?php endif; ?>
                                        <option value="today">Today</option>
                                        <option value="yesterday">Yesterday</option>
                                        <option value="week">Last 7 Days</option>
                                        <option value="month">Last Month</option>
                                    </select>
                                </div>
                            <div class="form-group">
                                <label>Issue Status</label>
                                <select name="status" class="form-control text-capitalize">
                                    <?php if( !empty ( $status ) ): ?>
                                        <option selected value="<?php echo e($status); ?>"><?php echo e($status); ?></option>
                                        <option value>select</option>

                                    <?php else: ?>
                                        <option selected value>select</option>
                                    <?php endif; ?>
                                    <option value="open">Open</option>
                                    <option value="closed">Closed</option>
                                    <option value="over due">Over Due</option>
                                    <option value="under process">Under Process</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Users</label>
                                <select name="user" class="form-control text-capitalize">
                                    <?php if( !empty($assigned_user ) ): ?>
                                        <option selected value="<?php echo e($assigned_user->id); ?>"><?php echo e($assigned_user->username); ?></option>
                                        <option value>select</option>

                                    <?php else: ?>
                                        <option selected value>select</option>
                                    <?php endif; ?>

                                  
                                </select>
                            </div>

                            <div class="form-group clearfix">
                                <button type="submit" class="btn btn-success pull-right rounded"> Search </button>
                            </div>

                            <?php echo e(Form::close()); ?>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="modal fade in" id="intimate">
        <div class="modal-dialog">
            <div class="modal-content">
                <?php echo e(Form::open(['url' => '/intimate/complaint'])); ?>

                <div class="modal-header info">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span></button>
                    <h4 class="modal-title">Intimate the Complainant</h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <select name="complaint_id" class="form-control intimation select2" style="width: 100%">
                            <option selected value>Select Complainant</option>
                            <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($items->id); ?>"><?php echo e($items->complainant_name); ?> (<?php echo e($items->token); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="alert alert-info get_values" style="padding: 5px; margin-bottom: 5px">
                    </div>

                    <div class="form-group">
                        <label>Email Subject</label>
                        <input type="text" class="form-control" name="subject"/>
                    </div>

                    <div class="form-group">
                        <label>Reply to Complainant through Email</label>
                        <textarea class="form-control" name="description"></textarea>
                    </div>
                    <hr>

                    <div class="form-group">
                        <label>Add Comments that will be shown on CMS</label>
                        <textarea class="form-control" name="user_comment"></textarea>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-info">Intimate</button>
                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            $(".get_values").hide();
           $(".intimation").on('change', function () {
               var id = $(this).val();
               $.ajax({
                   type:    'POST',
                   url:     '<?php echo e(url('/get_complain')); ?>',
                   data:{
                       id:       id,
                       '_token': '<?php echo e(csrf_token()); ?>',
                   },

                   success: function (data) {
                       $(".get_values").show();
                       $(".get_values").html(data);
                   },
                   error: function () {
                       $(".get_values").hide();
                   }

               });


           });
        });
    </script>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>