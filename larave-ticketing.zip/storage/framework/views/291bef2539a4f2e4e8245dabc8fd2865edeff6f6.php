<html>
<head></head>
<body style="background: white; color: #000">
<h1>Hello <?php echo e($name); ?></h1>
<p><?php echo e($description); ?></p>
</body>
</html>