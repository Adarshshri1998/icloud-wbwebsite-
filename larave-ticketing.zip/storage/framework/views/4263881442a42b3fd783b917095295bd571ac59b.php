<?php $__env->startSection('title', 'Profile Settings'); ?>
<?php $__env->startSection('content'); ?>

    <section id="main-home">
        <div class="main-home">
            <div class="main-img-area app">
                <div class="container">
                    <h1>Profile Settings</h1>
                </div>
            </div>
        </div>
    </section>

    <section id="category-one">
        <div class="category-one">
            <div class="container contact">
                <div class="submit-area">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                            <?php echo e(Form::open(['url'=>'/profile/settings', 'files' => true])); ?>

                            <div class="small-border"></div>
                            <small></small>
                            <h1>Profile Settings</h1>
                            <hr>
                            <?php if(count($errors->all())): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        <strong>Alert!</strong> <?php echo e($error); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <?php if(Session::has('message')): ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <strong>Alert!</strong> <?php echo e(Session::get('message')); ?>

                                </div>
                            <?php endif; ?>

                            <div class="form-group">
                                <label class="control-label">Name:</label>
                                <input type="text"  name="name" class="form-control" value="<?php echo e($user->name); ?>" required/>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Username:</label>
                                <input type="text"  name="username" class="form-control" value="<?php echo e($user->username); ?>" required/>
                            </div>


                            <div class="form-group">
                                <label class="control-label">Email:</label>
                                <input type="email"  name="email" class="form-control" value="<?php echo e($user->email); ?>" required/>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Avatar:</label>
                                <div class="custom-file-upload">
                                    <input type="file" id="file" name="file" />
                                </div>
                            </div>

                            <div class="submit-button">
                                <button type="submit" class="btn btn-default">SUBMIT</button>
                            </div>

                            <?php echo e(Form::close()); ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            $('.file-upload-input').attr('value', '<?php echo e($user->avatar); ?>');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>