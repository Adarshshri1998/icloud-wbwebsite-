
<?php $__env->startSection('title', 'Settings'); ?>
<?php $__env->startSection('content'); ?>
    <section id="category-one">
        <div class="category-one">
            <div class="container contact">
                <div class="submit-area">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                            <?php echo e(Form::open(['url'=>'admin/settings/', 'class'=>'defaultForm','method' =>'post',  'files' => true])); ?>

                            <input type="hidden" name="id" value="<?php echo e($settings->id); ?>">
                            <div class="small-border"></div>
                            <h1>General Settings</h1>
                            <hr>

                            <?php if(count($errors->all())): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        <strong>Alert!</strong> <?php echo e($error); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <?php if(Session::has('error')): ?>
                                <div class="alert alert-danger alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <strong>Alert!</strong> <?php echo e(Session::get('error')); ?>

                                </div>
                            <?php endif; ?>

                            <?php if(Session::has('message')): ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <strong>Alert!</strong> <?php echo e(Session::get('message')); ?>

                                </div>
                            <?php endif; ?>
                            <div class="form-group">
                                <label class="control-label">Name*:</label>
                                <input type="text" class="form-control" name="name" value="<?php echo e($settings->name); ?>" required/>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Logo*:</label>
                                <div class="custom-file-upload logo">
                                    <input type="file" id="file" name="logo" value="<?php echo e($settings->logo); ?>" accept="image/x-png,image/gif,image/jpeg"/>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Email*:</label>
                                    <input type="email"  name="admin_email" class="form-control" value="<?php echo e($settings->admin_email); ?>"/>
                            </div>


                            <div class="form-group">
                                <label class="control-label">Keywords:</label>
                                <input type="text" class="form-control" name="keywords" value="<?php echo e($settings->keyword); ?>"/>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Description:</label>
                                <textarea class="form-control" name="description"><?php echo e($settings->description); ?></textarea>
                            </div>

                            <br>

                            <div class="small-border"></div>
                            <h1>Footer Setting</h1>

                            <div class="form-group">
                                <label class="control-label">Footer Logo*:</label>
                                <div class="custom-file-upload footer_logo">
                                    <input type="file" id="file" name="footer_logo" value="<?php echo e($settings->footer_logo); ?>" accept="image/x-png,image/gif,image/jpeg"/>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Footer Description*:</label>
                                <textarea class="form-control" name="footer_description"><?php echo e($settings->footer_description); ?></textarea>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Copyrights*:</label>
                                <input type="text" class="form-control" name="copyrights" value="<?php echo e($settings->copyrights); ?>"/>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Facebook:</label>
                                <input type="text" class="form-control" name="facebook" value="<?php echo e($settings->facebook); ?>"/>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Twitter:</label>
                                <input type="text" class="form-control" name="twitter" value="<?php echo e($settings->twitter); ?>"/>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Linkedin:</label>
                                <input type="text" class="form-control" name="linkedin" value="<?php echo e($settings->linkedin); ?>"/>
                            </div>

                            <br>

                            <div class="small-border"></div>
                            <h1>Ticket Setting</h1>

                            <div class="form-group">
                                <label class="control-label">Send Email on New Ticket*:</label>
                                <select name="ticket_email" class="form-control">
                                    <option value="yes" <?php echo e(($settings->ticket_email) == 'yes' ? 'selected' : ''); ?>>Yes</option>
                                    <option value="no" <?php echo e(($settings->ticket_email) == 'no' ? 'selected' : ''); ?>>No</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Client Can Edit Tickets*:</label>
                                <select name="client_can_edit" class="form-control">
                                    <option value="yes" <?php echo e(($settings->client_can_edit) == 'yes' ? 'selected' : ''); ?>>Yes</option>
                                    <option value="no" <?php echo e(($settings->client_can_edit) == 'no' ? 'selected' : ''); ?>>No</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Staff Can Edit Tickets*:</label>
                                <select name="staff_can_edit" class="form-control">
                                    <option value="yes" <?php echo e(($settings->staff_can_edit) == 'yes' ? 'selected' : ''); ?>>Yes</option>
                                    <option value="no" <?php echo e(($settings->staff_can_edit) == 'no' ? 'selected' : ''); ?>>No</option>
                                </select>
                            </div>


                            <div class="submit-button">
                                <button type="submit" class="btn btn-default">SUBMIT</button>
                            </div>

                            <?php echo e(Form::close()); ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            $('.custom-file-upload.logo .file-upload-input').attr('value', '<?php echo e($settings->logo); ?>');
            $('.custom-file-upload.footer_logo .file-upload-input').attr('value', '<?php echo e($settings->footer_logo); ?>');
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.tickets', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>