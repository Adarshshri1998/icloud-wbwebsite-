<?php $__env->startSection('title', 'Complaint Management System'); ?>
<?php $__env->startSection('content'); ?>



    <div class="validation-page">
        <div class="container text-center">
<br>


            <p>
                Welcome to Punjab Public Service Commission Complaint Management System.<br> Please use online Complaint Management System to register your complaint or track status of your complaint.</p>
        </div>
        <br>
        <br>
<div class="container">
    <div class="row">
        <div class="col-sm-6">
            <div class="panel panel-default">
                <div class="panel-heading">Register New Complaint</div>
                <div class="panel-body">

                    <?php echo e(Form::open(['url'=>'/new/complaint', 'class'=>'defaultForm'])); ?>


                    <div class="form-group">
                        <label class="control-label">Complainant Name:</label>
                        <input type="text" class="form-control" name="name" placeholder="Enter Your Name"/>
                        <span class="help-block" id="message"></span>
                    </div>


                    <div class="form-group">
                        <label class="control-label">CNIC No:</label>
                        <input type="text" class="form-control" name="cnic" placeholder="CNIC #" />
                        <span class="help-block" id="cnic"></span>
                        <span class="text-muted">(e.g xxxxx-xxxxxxx-x)</span>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-success pull-right rounded">Next Step <i class="fa fa-arrow-right"></i> </button>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="panel panel-default">
                <div class="panel-heading">Track Your Complaint</div>
                <div class="panel-body">
                    <?php echo e(Form::open(['url'=>'/track', 'class'=>'defaultForm'])); ?>

                        <div class="form-group">
                            <label class="control-label">Token No:</label>
                            <input type="text" class="form-control" name="token" placeholder="Token Number" />
                            <span class="help-block" id="token"></span>
                        </div>


                        <div class="form-group">
                            <label class="control-label">CNIC No:</label>
                            <input type="text" class="form-control" name="token_cnic" placeholder="CNIC #" />
                            <span class="help-block" id="token_cnic"></span>
                            <span class="text-muted">(e.g xxxxx-xxxxxxx-x)</span>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-success pull-right rounded">Next Step <i class="fa fa-arrow-right"></i> </button>
                        </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>
</div>


    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function() {

            $('.defaultForm').formValidation({
                message: 'This value is not valid',
                icon: {
                    valid: 'glyphicon glyphicon-ok',
                    invalid: 'glyphicon glyphicon-remove',
                    validating: 'glyphicon glyphicon-refresh'
                },
                fields: {
                    name: {
                        err: '#message',
                        validators: {
                            notEmpty: {
                                message: 'Title field is required and cannot be empty'
                            },
                            regexp: {
                                regexp: /^[a-z A-Z]+$/,
                                message: 'Title only contain alphabets and spaces'
                            },
                        }
                    },
                    cnic: {
                        err: '#cnic',
                        validators: {
                            notEmpty: {
                                message: 'Please enter your CNIC number'
                            },
                            regexp: {
                                regexp: /^[0-9+]{5}-[0-9+]{7}-[0-9+]{1}$/,
                                message: 'Please enter a valid CNIC number'
                            },
                        }
                    },
                    token: {
                        err: '#token',
                        validators: {
                            notEmpty: {
                                message: 'Please enter your token number'
                            }
                        }
                    },
                    token_cnic: {
                        err: '#token_cnic',
                        validators: {
                            notEmpty: {
                                message: 'Please enter your CNIC number'
                            },
                            regexp: {
                                regexp: /^[0-9+]{5}-[0-9+]{7}-[0-9+]{1}$/,
                                message: 'Please enter a valid CNIC number'
                            },
                        }
                    },

                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>