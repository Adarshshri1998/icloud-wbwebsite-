
<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

    <section id="follow-ticket">
        <div class="follow-ticket">
            <div class="follow-text">
                <div class="container">
                    <h1>Didn’t find what you want?</h1><br>
                    <a href="<?php echo e(url('/new/ticket')); ?>" class="btn btn-default">Create New Ticket</a>
                </div>
            </div>
        </div>
    </section>

    <section id="login-role">
            <div class="login-role">
                <div class="container">
                <div class="text-area">

                    <h1>Try Login With Different Roles</h1>
                    <div class="row">
                        <div class="col-md-offset-2 col-md-8">
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="login-home-box">
                                        <h3><i class="fa fa-user"></i> Admin</h3>
                                        <ul>
                                            <li>
                                                <i class="fa fa-user"></i><strong>username:</strong> admin</li>
                                            <li><i class="fa fa-lock"></i><strong>Password:</strong> 123456</li>

                                        </ul>
                                    </div>

                                </div>
                                <div class="col-sm-4">
                                    <div class="login-home-box">
                                        <h3><i class="fa fa-user"></i> Client</h3>
                                        <ul>
                                            <li><i class="fa fa-user"></i><strong>username:</strong> client</li>
                                            <li><i class="fa fa-lock"></i><strong>Password:</strong> 123456</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="login-home-box">
                                        <h3><i class="fa fa-user"></i> Staff</h3>
                                        <ul>
                                            <li><i class="fa fa-user"></i><strong>username:</strong> staff</li>
                                            <li><i class="fa fa-lock"></i><strong>Password:</strong> 123456</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>


    <div class="content faq">
        <div class="container">
            <h1>Search Our FAQ</h1>
            <ul class="nav nav-tabs">
                <?php $__currentLoopData = $departmetns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departmetn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="#<?php echo e(str_replace(' ', '-', strtolower($departmetn))); ?>" data-toggle="tab">
                            <?php echo e(ucwords($departmetn)); ?> <i class="fa fa-caret-up"></i>
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="tab-content">
                <?php $__currentLoopData = $departmetns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departmetn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="<?php echo e(str_replace(' ', '-', strtolower($departmetn))); ?>" class="tab-pane ">
                        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(str_replace(' ', '-', strtolower($faq->departments->name)) == str_replace(' ', '-', strtolower($departmetn))): ?>
                                <div class="tab-text">
                                    <a data-toggle="collapse" class="" href="#<?php echo e($faq->id); ?>">
                                        <i class="fa fa-plus"></i> <?php echo e($faq->subject); ?>

                                    </a>
                                    <div id="<?php echo e($faq->id); ?>" class="panel-collapse collapse in">
                                        <p>
                                            <?php echo e($faq->description); ?>

                                        </p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>