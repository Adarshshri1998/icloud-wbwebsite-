<div class="row" id="floating-header">
    <div class="top-right links pull-left">
        <a class="noPadding" href="
        <?php if (\Entrust::hasRole((''))) : ?>
        <?php echo e(url('/')); ?>

        <?php endif; // Entrust::hasRole ?>
        <?php if (\Entrust::hasRole(('Focal'))) : ?>
        <?php echo e(url('/home')); ?>

        <?php endif; // Entrust::hasRole ?>
        <?php if (\Entrust::hasRole(('Admin'))) : ?>
        <?php echo e(url('/admin')); ?>

        <?php endif; // Entrust::hasRole ?>
        <?php if (\Entrust::hasRole(('Director'))) : ?>
        <?php echo e(url('/director')); ?>

        <?php endif; // Entrust::hasRole ?>"><img src="../assets/images/ppsc_logo.png" alt="PPSC Logo" ></a>
    </div>

        <div class="top-right links pull-right">

                <a href="<?php echo e(url('/')); ?>">Home</a>
            <?php if($user = Auth::user()): ?>
               <a href="
        <?php if (\Entrust::hasRole((''))) : ?>
               <?php echo e(url('/')); ?>

               <?php endif; // Entrust::hasRole ?>
               <?php if (\Entrust::hasRole(('Focal'))) : ?>
               <?php echo e(url('/home')); ?>

               <?php endif; // Entrust::hasRole ?>
               <?php if (\Entrust::hasRole(('Admin'))) : ?>
               <?php echo e(url('/admin')); ?>

               <?php endif; // Entrust::hasRole ?>
               <?php if (\Entrust::hasRole(('Director'))) : ?>
               <?php echo e(url('/director')); ?>

               <?php endif; // Entrust::hasRole ?>"><?php echo e(Auth::user()->name); ?>!</a>
                <a href="<?php echo e(url('/logout')); ?>"
                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                    Logout
                </a>

                <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                </form>
            <?php else: ?>
                <a href="<?php echo e(url('/login')); ?>">Login</a>

                <?php endif; ?>



        </div>




</div>