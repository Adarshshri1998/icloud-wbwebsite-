
<?php $__env->startSection('title', 'Edit FAQ'); ?>
<?php $__env->startSection('content'); ?>
    <section id="category-one">
        <div class="category-one">
            <div class="container contact">
                <div class="submit-area">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">

                            <?php echo e(Form::open(['url'=>['/admin/faq', $faq->id], 'class'=>'defaultForm','method' =>'PUT'])); ?>

                            <div class="small-border"></div>
                            <small>Edit</small>
                            <h1>QUESTION</h1>
                            <hr>
                            <?php if(count($errors->all())): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        <strong>Alert!</strong> <?php echo e($error); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <?php if(Session::has('message')): ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <strong>Alert!</strong> <?php echo e(Session::get('message')); ?>

                                </div>
                            <?php endif; ?>
                            <div class="form-group">
                                <label class="control-label">Department:</label>
                                <select name="department" class="form-control" required>
                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($faq->department_id == $department->id): ?>
                                            <option value="<?php echo e($department->id); ?>" selected><?php echo e($department->name); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Subject*:</label>
                                <input type="text" class="form-control" name="subject" value="<?php echo e($faq->subject); ?>" required/>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Description:</label>
                                <textarea class="form-control" name="description" required><?php echo e($faq->description); ?></textarea>
                            </div>

                            <div class="submit-button">
                                <button type="submit" class="btn btn-default">UPDATE</button>
                            </div>

                            <?php echo e(Form::close()); ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.tickets', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>