<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo e($settings->description); ?>">
    <meta name="keywords" content="<?php echo e($settings->keywords); ?>">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Ticket Plus | <?php echo $__env->yieldContent('title'); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('plugin/bootstrap-3.3.7/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugin/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugin/sweetalert/dist/sweetalert.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugin/datatable/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugin/slick/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.min.css')); ?>">

    <link rel="icon" href="<?php echo e(asset('images/fav.png')); ?>" type="image/x-icon"/>

    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>;
    </script>
</head>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand navbar-link" href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('uploads')); ?>/<?php echo e($settings->logo); ?>" alt="LOGO"></a>
            <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse" id="navcol-1">
            <ul class="nav navbar-nav navbar-right">
                <li class="about"><a href="<?php echo e(url('/about')); ?>">About</a></li>
                <li class="contact"><a href="<?php echo e(url('/contact')); ?>">Contact</a></li>
                <?php if(Auth::user()): ?>
                    <?php if(Auth::user()->hasRole('admin')): ?>
                        <li class="ticket"><a href="<?php echo e(url('tickets')); ?>">Dashboard</a></li>
                        <?php else: ?>
                        <li class="ticket"><a href="<?php echo e(url('tickets')); ?>">Tickets</a></li>
                    <?php endif; ?>

                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle clearfix" data-toggle="dropdown">
                            Notifications <span class="badge"><?php echo e(count(Auth::user()->unreadNotifications)); ?></span>
                        </a>
                        <ul class="dropdown-menu notification_dropdown">
                            <?php $__currentLoopData = Auth::user()->notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($notification->type == 'App\Notifications\TicketReply'): ?>
                                    <li>
                                        <a href="<?php echo e(url('ticket')); ?>/<?php echo e($notification->data['ticket_id']); ?>/<?php echo e(str_replace(' ', '-',   strtolower($notification->data['ticket_title']))); ?>">
                                            <strong class="badge"><?php echo e($notification->data['reply_user']); ?></strong>
                                            <small>replied to a ticket</small>
                                            <br><span class="ticket_small_title"><?php echo e($notification->data['ticket_title']); ?></span>
                                        </a>
                                    </li>
                                <?php endif; ?>

                                    <?php if($notification->type == 'App\Notifications\TicketStatus'): ?>
                                        <li>
                                            <a href="<?php echo e(url('ticket')); ?>/<?php echo e($notification->data['ticket_id']); ?>/<?php echo e(str_replace(' ', '-',   strtolower($notification->data['ticket_title']))); ?>">
                                                <small>Ticket status changed to</small>
                                                <strong class="badge"><?php echo e($notification->data['status']); ?></strong>
                                                <br>
                                                <span class="ticket_small_title"> <?php echo e($notification->data['ticket_title']); ?></span>
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if($notification->type == 'App\Notifications\NewTicket'): ?>
                                        <li>
                                            <a href="<?php echo e(url('ticket')); ?>/<?php echo e($notification->data['ticket_id']); ?>/<?php echo e(str_replace(' ', '-',   strtolower($notification->data['ticket_title']))); ?>">
                                                <small>New ticket created by</small>
                                                <strong class="badge"><?php echo e($notification->data['user_name']); ?></strong>
                                                <br>
                                                <span class="ticket_small_title"> <?php echo e($notification->data['ticket_title']); ?></span>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>

                    <li class="dropdown profile">
                        <a href="#" class="dropdown-toggle clearfix" data-toggle="dropdown">
                            <?php if(Auth::user()->avatar == null): ?>
                                <span class="avatar"><img src="<?php echo e(asset('uploads/avatar.png')); ?>" alt="avatar"></span>
                            <?php else: ?>
                                <span class="avatar"><img src="<?php echo e(asset('uploads')); ?>/<?php echo e(Auth::user()->avatar); ?>" alt="avatar"></span>

                            <?php endif; ?>
                            <span class="user_name"><?php echo e(Auth::user()->name); ?></span>
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo e(url('profile/settings')); ?>"><i class="fa fa-gear"></i> Profile Settings</a></li>
                            <li><a href="<?php echo e(url('change/password')); ?>"><i class="fa fa-lock"></i> Change Password</a></li>
                            <li role="separator" class="divider"></li>
                            <li>
                                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                                    <i class="fa fa-lock"></i> Logout
                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </li>
                        </ul>
                    </li>

                <?php endif; ?>

                <?php if(Auth::guest()): ?>
                    <li><a href="<?php echo e(url('login')); ?>">Login</a></li>
                    <li><a href="<?php echo e(url('register')); ?>" >Register</a></li>
                <?php endif; ?>
                <li><a href="<?php echo e(url('new/ticket')); ?>" class="new_ticket">New Ticket</a></li>
            </ul>
        </div>
    </div>
</nav>
<?php echo $__env->yieldContent('content'); ?>


<section id="footer">
    <footer>
        <div class="footer">
            <div class="container">
                <div class="row">
                    <div class="footer-content">
                        <div class="col-md-12">
                            <div class="section-one">
                                <img src="<?php echo e(asset('uploads')); ?>/<?php echo e($settings->footer_logo); ?>" class="img-responsive" alt="Nothing">
                                <p class="media-body"><?php echo e($settings->footer_description); ?>

                                </p>
                                <div class="social-icon">
                                    <ul>
                                        <li><a href="<?php echo e($settings->facebook); ?>" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="<?php echo e($settings->twitter); ?>" target="_blank"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="<?php echo e($settings->linkedin); ?>" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="registered">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="one text-center">
                                <p><?php echo e($settings->copyrights); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</section>

<!--jquery-->
<script src="<?php echo e(asset('plugin/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugin/bootstrap-3.3.7/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugin/sweetalert/dist/sweetalert.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugin/datatable/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugin/slick/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>

<script>
    $('.notification_dropdown li a').on('click', function () {
        $.ajax({
            type: 'GET',
            url: '<?php echo e(url('/markAsRead')); ?>'
        })
    });
</script>
<?php echo $__env->yieldContent('script'); ?>

</body>
</html>
