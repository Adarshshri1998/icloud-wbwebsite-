

<?php $__env->startSection('title', 'Tickets'); ?>

<?php $__env->startSection('content'); ?>

    <section id="main-home">
        <div class="main-home">
            <div class="main-img-area app">
                <div class="container">
                    <h1>Tickets List</h1>
                    <?php if (\Entrust::hasRole('staff')) : ?>
                    <p>Table contains all the tickets that assigned to you or the tickets that submitted by you</p>
                    <?php endif; // Entrust::hasRole ?>
                    <?php if (\Entrust::hasRole('client')) : ?>
                    <p>Table contains all the tickets that you submitted</p>
                    <?php endif; // Entrust::hasRole ?>
                </div>
            </div>
        </div>
    </section>

    <div class="page-content">
        <section id="category-one">
            <div class="category-one">
                <div class="container">
                    <div class="row">
                        <div class="col-md-9 col-sm-12">
                            <div class="table-section">
                                <h3 class="title clearfix">Tickets <span>List</span></h3>
                                <div class="table-responsive">
                                    <table class="table table-lead ticket-table">
                                        <thead>
                                        <tr>
                                            <th class="heading">Token #</th>
                                            <th class="heading">Title</th>
                                            <th class="heading">Department</th>
                                            <?php if (\Entrust::hasRole('staff')) : ?>
                                            <th class="heading">Submitted By</th>
                                            <?php endif; // Entrust::hasRole ?>
                                            <th class="heading">Status</th>
                                            <th class="heading">Date</th>
                                            <th class="heading">action</th>
                                        </tr>
                                        </thead>
                                        <tbody>

                                        <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($ticket->user_id == Auth::id() || $ticket->assigned_to == Auth::id()): ?>
                                                <tr id="<?php echo e($ticket->id); ?>">
                                                    <td><?php echo e($ticket->token_no); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(url('ticket')); ?>/<?php echo e($ticket->id); ?>/<?php echo e(str_replace(' ', '-',   strtolower($ticket->subject) )); ?>"><?php echo e($ticket->subject); ?></a></td>
                                                    <td><?php echo e($ticket->departments->name); ?></td>
                                                    <?php if (\Entrust::hasRole('staff')) : ?>
                                                    <?php if($ticket->user_id == Auth::id()): ?>
                                                        <td>me</td>
                                                    <?php else: ?>
                                                        <td><?php echo e($ticket->submittedBy->name); ?></td>
                                                    <?php endif; ?>
                                                    <?php endif; // Entrust::hasRole ?>

                                                    <td>
                                                    <span class="ticket-status <?php echo e($ticket->status); ?>">
                                                        <?php echo e($ticket->status); ?>

                                                    </span>
                                                    </td>

                                                    <td><?php echo e($ticket->created_at->format('d-m-Y')); ?></td>
                                                    <td>
                                                        <?php if(Auth::user()->hasRole('client')): ?>
                                                            <?php if($settings->client_can_edit == 'yes'): ?>
                                                                <a href="<?php echo e(url('edit/tickets')); ?>/<?php echo e($ticket->id); ?>" class="eye" data-id="<?php echo e($ticket->id); ?>">
                                                                    <i class="fa fa-pencil"></i>
                                                                </a>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                        <?php if(Auth::user()->hasRole('staff')): ?>
                                                            <?php if($settings->staff_can_edit == 'yes'): ?>
                                                                <a href="<?php echo e(url('edit/tickets')); ?>/<?php echo e($ticket->id); ?>" class="eye" data-id="<?php echo e($ticket->id); ?>">
                                                                    <i class="fa fa-pencil"></i>
                                                                </a>
                                                            <?php endif; ?>
                                                        <?php endif; ?>


                                                        <a href="javascript:;" class="eye delete-btn" data-id="<?php echo e($ticket->id); ?>">
                                                            <i class="fa fa-trash"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div>
                                <?php echo e($tickets->links()); ?>

                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="second-heading-area">
                                <div class="search_box clearfix">
                                    <form action="<?php echo e(url('find/ticket')); ?>" method="get">
                                        <?php if(!empty($search_term)): ?>
                                            <input type="text" name="q" class="form-control" placeholder="Search Ticket" required value="<?php echo e($search_term); ?>">
                                        <?php else: ?>
                                            <input type="text" name="q" class="form-control" placeholder="Search Ticket" required>
                                        <?php endif; ?>
                                        <button type="submit" class="basic-button">Submit</button>
                                    </form>
                                </div>
                                <div class="ticket-info">
                                    <div class="title-sidebar">
                                        <h1>Search By Status</h1>
                                    </div>
                                    <div class="catege-one">
                                        <ul>
                                            <li>
                                                <a href="<?php echo e(url('find/status/open')); ?>" class="open">
                                                    Open Tickets
                                                    <span class="number-box"><?php echo e($open); ?></span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(url('find/status/closed')); ?>" class="closed">
                                                    Closed Tickets
                                                    <span class="number-box"> <?php echo e($closed); ?></span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(url('find/status/pending')); ?>" class="pending">
                                                    Pending Tickets
                                                    <span class="number-box"><?php echo e($pending); ?></span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(url('find/status/replied')); ?>" class="replied">
                                                    Replied Tickets
                                                    <span class="number-box"><?php echo e($replied); ?></span>
                                                </a>
                                            </li>

                                            <li>
                                                <a href="<?php echo e(url('tickets')); ?>">
                                                    View All
                                                    <span class="number-box"><?php echo e(count($tickets_depart)); ?></span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="ticket-info">
                                    <div class="title-sidebar">
                                        <h1>Departments</h1>
                                        <div class="catege-one">
                                            <ul>
                                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $count = 0?>
                                                    <?php $__currentLoopData = $tickets_depart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($item->department_id == $department->id): ?>
                                                            <?php $count++?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <a href="<?php echo e(url('find/department')); ?>/<?php echo e($department->id); ?>">
                                                            <?php echo e($department->name); ?>

                                                            <span class="number-box"><?php echo e($count); ?></span>
                                                        </a>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            $('.navbar-default .navbar-nav li').removeClass('active');
            $('.navbar-default .navbar-nav li.ticket').addClass('active');
            $(".delete-btn").on('click', function () {
                var id = $(this).attr('data-id');
                swal({
                            title: "Are you sure?",
                            type: "warning",
                            showCancelButton: true,
                            confirmButtonColor: "#DD6B55",
                            confirmButtonText: "Yes, delete it!",
                            cancelButtonText: "No, cancel!",
                            closeOnConfirm: false,
                            closeOnCancel: true
                        },
                        function(isConfirm){
                            if (isConfirm) {
                                $.ajax({
                                    type: 'POST',
                                    url: '<?php echo e(url('/delete/tickets')); ?>'+"/"+id,
                                    data:{
                                        id:id,
                                        '_token': '<?php echo e(csrf_token()); ?>'
                                    },
                                    success: function (data) {
                                        $('.ticket-table tr#'+id+'').hide();
                                        swal("Deleted!", "Record has been deleted.", "success");

                                    }
                                })
                            } else {
                                swal("Cancelled", "Record is safe :)", "error");
                            }
                        });
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>