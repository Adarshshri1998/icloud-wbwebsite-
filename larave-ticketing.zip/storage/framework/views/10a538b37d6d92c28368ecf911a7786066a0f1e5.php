<?php $__env->startSection('title', 'Complaint Comments'); ?>
<?php $__env->startSection('content'); ?>

    <div class="validation-page">
        <div class="container-fluid text-center">
            <h2>Complaint Management</h2>
        </div>
        <br>
        <br>
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-offset-2 col-sm-8">
                    <div class="panel panel-default with-button">

                        <div class="panel-heading clearfix">
                            <span> Complaint View &nbsp;</span>
                                 <span class="text-muted">
                                       <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         (<?php echo e($complaint->complainant_name); ?> (<?php echo e($complaint->token); ?>))
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </span>

                            <div class="header-button pull-right">
                                <a href="javascript:window.open('','_self').close();" class="btn btn-primary rounded noMargin">Close</a>
                            </div>
                        </div>


                        <div class="panel-body">

                            <table class="table data-table table-bordered table-striped">
                                <thead>
                                <tr>
                                    <th>Comment</th>
                                    <th>User</th>
                                    <th>Date</th>
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                    <th>Comment</th>
                                    <th>User</th>
                                    <th>Date</th>
                                </tr>
                                </tfoot>
                                <tbody>
                                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($comment->comment != null): ?>
                                        <tr>
                                            <td><?php echo e($comment->comment); ?></td>
                                            <td><?php echo e($comment->users->username); ?></td>
                                            <td><?php echo e($comment->created_at); ?></td>
                                        </tr>
                                    <?php endif; ?>

                                    <?php if($comment->user_comment != null): ?>
                                        <tr>
                                            <td><?php echo e($comment->user_comment); ?></td>
                                            <?php if($comment->user_id != null): ?>
                                                <td>Focal person</td>
                                            <?php else: ?>
                                                <td>Complainant</td>
                                            <?php endif; ?>
                                            <td><?php echo e($comment->created_at); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>