<?php $__env->startSection('title', 'Edit Ticket'); ?>
<?php $__env->startSection('content'); ?>
    <section id="main-home">
        <div class="main-home">
            <div class="main-img-area app">
                <div class="container">
                    <h1>Edit Ticket</h1>
                </div>
            </div>
        </div>
    </section>
    <section id="category-one">
        <div class="category-one">
            <div class="container contact">
                <div class="submit-area">
                    <div class="row">
                        <div class="col-md-9">
                            <?php if(count($errors->all())): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        <strong>Alert!</strong> <?php echo e($error); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>


                            <?php echo e(Form::open(['url'=>['/update/tickets',$ticket->id], 'class'=>'defaultForm','method' =>'post',  'files' => true])); ?>

                            <div class="small-border"></div>
                            <small>Edit Ticket</small>
                            <hr>

                            <?php if(Session::has('message')): ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <strong>Alert!</strong> <?php echo e(Session::get('message')); ?>

                                </div>
                            <?php endif; ?>

                            <div class="form-group">
                                <label class="control-label">Title*:</label>
                                <input type="text" class="form-control" name="subject" value="<?php echo e($ticket->subject); ?>" required/>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Department*:</label>
                                <select name="department" required class="form-control">
                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($department->id); ?>" <?php echo e(($department->id) == $ticket->department_id ? 'selected' : ''); ?>><?php echo e($department->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Description:</label>
                                <textarea class="form-control" name="description"  required><?php echo e($ticket->description); ?></textarea>
                                <span class="help-block" id="message"></span>
                            </div>

                            <div class="submit-button">
                                <button type="submit" class="btn btn-default">Update</button>
                            </div>

                            <?php echo e(Form::close()); ?>


                        </div>
                        <div class="col-md-3 col-sm-12">
                            <div class="ticket-info">
                                <div class="title-sidebar">
                                    <h1>Ticket information</h1>
                                </div>
                                <table class="table">
                                    <tbody>
                                    <tr>
                                        <td class="tno">#Token Number:</td>
                                        <td><span class="label-green"><?php echo e($ticket->token_no); ?></span></td>
                                    </tr>
                                    <tr>
                                        <td class="tno">Submitted By:</td>
                                        <td><span><?php echo e($ticket->submittedBy->name); ?></span></td>
                                    </tr>
                                    <tr>
                                        <td>Department</td>
                                        <td class="tno"><?php echo e($ticket->departments->name); ?></td>
                                    </tr>
                                    <tr>
                                        <td>ticket status</td>
                                        <td><span class="ticket-status <?php echo e($ticket->status); ?>"><?php echo e($ticket->status); ?></span></td>
                                    </tr>
                                    <tr>
                                        <td>Assigned ticket</td>
                                        <?php if($ticket->assigned_to  == null): ?>
                                            <td class="tno">not assigned</td>
                                        <?php else: ?>
                                            <td class="tno"><?php echo e($ticket->users->name); ?></td>
                                        <?php endif; ?>
                                    </tr>
                                    <?php if (\Entrust::hasRole('admin')) : ?>
                                    <tr>
                                        <td class="no-border">
                                            <span class="new-tk ticker">
                                                <a href="javascript:;" data-toggle="modal" data-target="#assign-ticket">
                                                    assign ticket
                                                </a>

                                            </span>
                                        </td>
                                        <td class="no-border">
                                            <span class="update-tk ticker">
                                                <a href="javascript:;" data-toggle="modal" data-target="#status-modal"> update status</a>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endif; // Entrust::hasRole ?>

                                    </tbody>
                                </table>
                            </div>
                            <!--ticket-files-->
                            <div class="ticket-files">
                                <div class="title-sidebar">
                                    <h1>Files</h1>
                                </div>
                                <table class="table">
                                    <tbody>
                                    <tr>
                                        <td>name</td>
                                        <td>uploaded by</td>
                                    </tr>

                                    <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <a href="<?php echo e(url('download')); ?>/<?php echo e($file->name); ?>" class="file-up"><?php echo e($file->name); ?></a>
                                            </td>
                                            <td><?php echo e($file->users->name); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>