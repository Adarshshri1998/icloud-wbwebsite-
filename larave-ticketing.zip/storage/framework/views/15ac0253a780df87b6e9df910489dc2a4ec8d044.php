
<?php $__env->startSection('title', 'Edit Admin'); ?>
<?php $__env->startSection('content'); ?>
    <section id="category-one">
        <div class="category-one">
            <div class="container contact">
                <div class="submit-area">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                            <?php if(count($errors->all())): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        <strong>Alert!</strong> <?php echo e($error); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <?php echo e(Form::open(['url'=>['/admin/admins',$user->id], 'class'=>'defaultForm','method' =>'PUT',  'files' => true])); ?>

                            <div class="small-border"></div>
                            <small>Edit Admin</small>
                            <h1>
                                <?php if($user->avatar ==  null): ?>
                                    <img src="<?php echo e(asset('uploads')); ?>/avatar.png" alt="avatar" class="img-circle" style="max-height: 40px;">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('uploads')); ?>/<?php echo e($user->avatar); ?>" alt="avatar" class="img-circle" style="max-height: 40px;">
                                <?php endif; ?>
                                <?php echo e($user->name); ?></h1>
                            <hr>

                            <div class="form-group">
                                <label class="control-label">Name*:</label>
                                <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" required/>
                            </div>

                            <div class="form-group">
                                <label class="control-label">User Name*:</label>
                                <input type="text" class="form-control" readonly name="username" value="<?php echo e($user->username); ?>" required/>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Email*:</label>
                                <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>" required/>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Avatar:</label>

                                <div class="custom-file-upload">
                                    <input type="file" id="file" name="file" value="<?php echo e($user->avatar); ?>"/>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Role*:</label>
                                <select name="role" class="form-control">
                                    <option value="admin" <?php if($user->hasRole('admin')): ?>selected <?php endif; ?>>Admin</option>
                                    <option value="staff" <?php if($user->hasRole('staff')): ?>selected <?php endif; ?>>Staff</option>
                                    <option value="client"  <?php if($user->hasRole('client')): ?>selected <?php endif; ?>>Client</option>
                                </select>
                            </div>

                            <div class="submit-button">
                                <button type="submit" class="btn btn-default">Update</button>
                            </div>

                            <?php echo e(Form::close()); ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            $('.file-upload-input').attr('value', '<?php echo e($user->avatar); ?>');
        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.tickets', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>