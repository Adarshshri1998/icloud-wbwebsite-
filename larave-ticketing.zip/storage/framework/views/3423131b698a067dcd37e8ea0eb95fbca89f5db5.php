<?php $__env->startSection('title', 'Add new Admin'); ?>
<?php $__env->startSection('content'); ?>
    <section id="category-one">
        <div class="category-one">
            <div class="container contact">
                <div class="submit-area">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">

                            <?php if(count($errors->all())): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        <strong>Alert!</strong> <?php echo e($error); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <?php echo e(Form::open(['url'=>'/admin/admins', 'method' =>'post',  'files' => true])); ?>

                            <div class="small-border"></div>
                            <h1>Add Admin</h1>
                            <hr>

                            <div class="form-group">
                                <label class="control-label">Name*:</label>
                                <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required/>
                            </div>

                            <div class="form-group">
                                <label class="control-label">User Name*:</label>
                                <input type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" required/>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Email*:</label>
                                <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required/>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Password*:</label>
                                <input type="password" class="form-control" name="password"  required/>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Avatar:</label>
                                <div class="custom-file-upload">
                                    <input type="file" id="file" name="file"/>
                                </div>
                            </div>


                            <div class="submit-button">
                                <button type="submit" class="btn btn-default">Submit</button>
                            </div>

                            <?php echo e(Form::close()); ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.tickets', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>