<?php $__env->startSection('title', 'Reset Password'); ?>
<?php $__env->startSection('content'); ?>

    <section id="main-home">
        <div class="main-home">
            <div class="main-img-area app">
                <div class="container">
                    <h1>Reset Password</h1>
                </div>
            </div>
        </div>
    </section>

    <section id="login">
        <div class="login">
            <div class="container">
                <div class="col-md-6">
                    <div class="login-area">
                        <div class="login-back"></div>
                        <div class="login-front">
                            <img src="<?php echo e(asset('images/ravitlash-logo.png')); ?>"  alt="nothing">
                            <p>Lorem Ipsum is simply dummy text of the printing and
                                typesetting industry. Lorem Ipsum has been the industry's
                                standard dummy text ever since the 1500s
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="login-text">
                        <form  method="POST" action="<?php echo e(route('password.request')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <h1>Reset Password</h1>

                            <?php if(count($errors->all())): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        <strong>Alert!</strong> <?php echo e($error); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <?php if(session('status')): ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <strong>Alert!</strong>  <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>

                            <div class="form-group">
                                <input type="hidden" name="token" value="<?php echo e($token); ?>">
                                <div class="form-group">
                                    <div class="icon">
                                        <span class="fa fa-envelope-o"></span>
                                    </div>
                                    <input type="email" placeholder="Email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                </div>

                                <div class="form-group">
                                    <div class="icon">
                                        <span class="fa fa-lock"></span>
                                    </div>
                                    <input id="password" placeholder="Password" type="password" class="form-control" name="password" required>
                                </div>

                                <div class="form-group">
                                    <div class="icon">
                                        <span class="fa fa-lock"></span>
                                    </div>
                                    <input placeholder="Confirm Password" type="password" class="form-control" name="password_confirmation" required>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-default login-button">Reset Password</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>