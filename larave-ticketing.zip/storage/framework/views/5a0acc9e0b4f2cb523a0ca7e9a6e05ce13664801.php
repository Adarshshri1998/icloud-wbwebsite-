<?php $__env->startSection('title', 'View Complaint'); ?>
<?php $__env->startSection('content'); ?>





    <div class="validation-page">
        <div class="container-fluid text-center">
            <h2>Complaint Management</h2>

        </div>
        <br>
        <br>
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-offset-2 col-sm-8">
                    <div class="panel panel-default with-button">
                        <div class="panel-heading clearfix">
                            <span>View Complaints Detail</span>
                            <div class="header-button pull-right">
                                <a href="javascript:window.open('','_self').close();" class="btn btn-primary rounded noMargin">Close</a>
                            </div>
                        </div>
                        <div class="panel-body">

                            <table class="table table-bordered table-striped">
                                <tbody>

                                <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <th style="width:30%">Complainant Name</th>
                                    <td><?php echo e($complaint->complainant_name); ?></td>
                                </tr>
                                <tr>
                                    <th style="width:30%">Father Name</th>
                                    <td><?php echo e($complaint->father_name); ?></td>
                                </tr>

                                <tr>
                                    <th style="width:30%">CNIC No</th>
                                    <td><?php echo e($complaint->cnic_no); ?></td>
                                </tr>

                                <tr>
                                    <th style="width:30%">Token Number</th>
                                    <td><?php echo e($complaint->token); ?></td>
                                </tr>

                                <tr>
                                    <th style="width:30%">Mobile</th>
                                    <td><?php echo e($complaint->mobile); ?></td>
                                </tr>

                                <tr>
                                    <th style="width:30%">Address</th>
                                    <td><?php echo e($complaint->address); ?></td>
                                </tr>

                                <tr>
                                    <th style="width:30%">Case Number</th>
                                    <td><?php echo e($complaint->case_no); ?></td>
                                </tr>
                                <tr>
                                    <th style="width:30%">Post Name</th>
                                    <td><?php echo e($complaint->post_name); ?></td>
                                </tr>
                                <tr>
                                    <th style="width:30%">Email</th>
                                    <td ><?php echo e($complaint->email); ?></td>
                                </tr>

                                <tr>
                                    <th style="width:30%">Subject</th>
                                    <td><?php echo e($complaint->Subject); ?></td>
                                </tr>

                                <tr>
                                    <th style="width:30%">Description</th>
                                    <td><?php echo e($complaint->description); ?></td>
                                </tr>

                                <tr>
                                    <th style="width:30%">Date</th>
                                    <td><?php echo e($complaint->created_at); ?></td>
                                </tr>

                                <tr>
                                    <th style="width:30%">Status</th>
                                    <td><?php echo e($complaint->status); ?></td>
                                </tr>

                                <tr>
                                    <th style="width:30%">Assigned to</th>
                                    <td>
                                        <?php if($complaint->assign_to != null): ?>
                                        <?php echo e($complaint->users->username); ?>

                                        <?php else: ?>
                                        NULL
                                            <?php endif; ?>
                                    </td>
                                </tr>

                                <tr>
                                    <th style="width:30%">Files</th>
                                        <td>
                                            <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a target="_blank" href="http://192.168.0.32:8000/uploads/<?php echo e($file->name); ?>" download  title="uploaded by <?php echo e($uploader); ?>"><span class="label label-default"><?php echo e($file->name); ?></span>
                                                </a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>