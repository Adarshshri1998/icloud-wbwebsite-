<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Styles -->
   
    <link rel="stylesheet" href="../assets/css/font-awesome.min.css"/>
    <link rel="stylesheet" href="../plugins/bootstrap/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="../plugins/formvalidation/dist/css/formValidation.min.css"/>
    <link rel="stylesheet" href="../plugins/dataTables/jquery.dataTables.min.css"/>
    <link rel="stylesheet" href="../plugins/select2/dist/css/select2.min.css"/>
    <link rel="stylesheet" href="../plugins/daterangepicker/daterangepicker.css"/>
    <link rel="stylesheet" href="../assets/css/app.css"/>
    <link rel="icon" href="../assets/images/fav.png" type="image/x-icon"/>
    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>;
    </script>
</head>
<body>
<div class="wrapper" data-ng-controller="mainController">
    <div class="loader">
        <i class="fa fa-gear"></i>
    </div>
    <div class="main-content">
    <?php echo $__env->make('partials.topbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
        <footer>
            <div class="copyrights">
                <a href="#" target="_blank">Powered By | Punjab Public Service Commission (IT-Wing)</a>
            </div>
        </footer>
    </div>
</div>

<!--jquery-->
<script src="../plugins/jquery/jquery-2.2.4.min.js"></script>
<!--lib-->
<script src="../assets/js/lib.js"></script>
<script src="../plugins/daterangepicker/moment.min.js"></script>
<script src="../plugins/daterangepicker/daterangepicker.js"></script>
<script src="../assets/js/app.js"></script>
<script>
    $(document).ready(function(){
        $('.data-table').DataTable();
        $('.select2').select2();
        $('.range-picker').daterangepicker({
            locale: {
                format: 'YYYY-MM-DD'
            }
        });
        $(".dropdown-menu").on('click', function (e) {
            e.stopPropagation();
        });
    });
</script>

<?php echo $__env->yieldContent('script'); ?>
</body>
</html>
