
<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('content'); ?>

    <section id="main-home">
        <div class="main-home">
            <div class="main-img-area app">
                <div class="container">
                    <h1>User Login</h1>
                </div>
            </div>
        </div>
    </section>

    <section id="login">
        <div class="login">
            <div class="container">
                <div class="col-md-6">
                    <div class="login-area">
                        <div class="login-back"></div>
                        <div class="login-front">
                            <div>
                                <img src="<?php echo e(asset('uploads')); ?>/<?php echo e($settings['logo']); ?>"  alt="logo">
                                <p>
                                    <?php echo e($settings['footer_description']); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="login-text">
                        <form role="form" method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>

                            <h1>LOGIN TO YOUR ACCOUNT</h1>

                            <?php if(count($errors->all())): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        <strong>Alert!</strong> <?php echo e($error); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <div class="form-group">
                                <div class="form-group">
                                    <div class="icon">
                                        <span class="fa fa-user" aria-hidden="true"></span>
                                    </div>
                                    <input id="username" type="text" class="form-control" placeholder="username or email" name="username" value="<?php echo e(old('username')); ?>" autofocus>
                                </div>

                                <div class="form-group">
                                    <div class="icon">
                                        <span class="fa fa-lock" aria-hidden="true"></span>
                                    </div>
                                    <input type="password" placeholder="Password" name="password" class="form-control">
                                </div>
                            </div>
                            <button type="submit" class="btn btn-default login-button">LOGIN NOW</button>
                            <ul>
                                <li>
                                    <a href="<?php echo e(asset('/password/reset')); ?>">Forget Your Password . ?</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('contact')); ?>">Need Support .</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(asset('/register')); ?>">Sign up .</a>
                                </li>
                            </ul>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            $('.navbar-default .navbar-nav li').removeClass('active');
            $('.navbar-default .navbar-nav li.login').addClass('active');
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>