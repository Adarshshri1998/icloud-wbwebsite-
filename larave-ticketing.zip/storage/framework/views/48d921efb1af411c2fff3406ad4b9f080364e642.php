<?php $__env->startSection('title', 'Complaint Detail'); ?>
<?php $__env->startSection('content'); ?>
    <div class="validation-page">
        <div class="container text-center">
            <h2>Complaint Detail</h2>
            <p>
                All fields marked with an <b>asterisk (*)</b> are required</p>
        </div>


        <div class="row">
            <div class="col-sm-8 col-sm-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Register New Complaint</div>
                    <div class="panel-body">

                        <?php echo e(Form::open(['url'=>'/update/complaint', 'class'=>'defaultForm',  'files' => true])); ?>

                        <input type="hidden" name='cnic' value="<?php echo e($cnic); ?>">
                        <input type="hidden" name='cname' value="<?php echo e($name); ?>">

                        <div class="form-group">
                            <label class="control-label">Complainant Name:</label>
                            <input type="text" class="form-control" disabled value="<?php echo e($name); ?>" />
                        </div>

                        <div class="form-group">
                            <label class="control-label">Father's Name*:</label>
                            <input type="text" class="form-control" name="fname" required/>
                            <span class="help-block" id="fname"></span>
                        </div>

                        <div class="form-group">
                            <label class="control-label">Address*:</label>
                            <input type="text" class="form-control" name="address" required/>
                            <span class="help-block" id="address"></span>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Email Address*:</label>
                            <input type="email" class="form-control" required name="email" data-fv-emailaddress-message="The input is not a valid email address"/>
                            <span class="help-block" id="email"></span>
                        </div>

                        <div class="form-group">
                            <label class="control-label">Phone No:</label>
                            <input type="text" class="form-control" name="phone" />
                        </div>

                        <div class="form-group">
                            <label class="control-label">Mobile No*:</label>
                            <input type="text" class="form-control" name="mobile" required/>
                            <span class="help-block" id="mobile"></span>
                        </div>

                        <div class="form-group">
                            <label class="control-label">Case No:</label>
                            <input type="text" class="form-control" name="case" />
                        </div>

                        <div class="form-group">
                            <label class="control-label">Post Name:</label>
                            <input type="text" class="form-control" name="post" />
                        </div>

                        <div class="form-group">
                            <label class="control-label">Attach File:</label>
                            <input type="file" class="form-control" name="file" />
                            <span class="help-block" id="file"></span>
                        </div>

                        <div class="form-group">
                            <label class="control-label">Subject*:</label>
                            <select name="subject" class="form-control" required>
                                <option value disabled selected>Select</option>
                                <option value="Interview">Interview</option>
                                <option value="Examination">Examination</option>
                                <option value="Apply Online">Apply Online</option>
                                <option value="Jobs">Jobs</option>
                                <option value="Syllabus">Syllabus</option>
                                <option value="Exams/Written Test">Exams/Written Test</option>
                                <option value="Result">Result</option>
                                <option value="Question Paper">Question Paper</option>
                                <option value="SMS">SMS</option>
                                <option value="Telephone">Telephone</option>
                                <option value="Other">Advisor Related</option>
                                <option value="Rules of PPSC">Rules of PPSC</option>
                                <option value="Academic Marking">Academic Marking</option>
                                <option value="Short Listing Procedure">Short Listing Procedure</option>
                                <option value="Interview Marking">Interview Marking</option>
                                <option value="Final Merit Procedure">Final Merit Procedure</option>
                                <option value="Any Other Feed Back">Any Other Feed Back</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="control-label">Description:</label>
                            <textarea class="form-control" name="description"></textarea>
                            <span class="help-block" id="message"></span>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-success pull-right rounded load">Next Step <i class="fa fa-arrow-right"></i> </button>
                        </div>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>
        $(function() {

            $('.defaultForm').formValidation({
                message: 'This value is not valid',
                icon: {
                    valid: 'glyphicon glyphicon-ok',
                    invalid: 'glyphicon glyphicon-remove',
                    validating: 'glyphicon glyphicon-refresh'
                },
                fields: {
                    cname: {
                        err: '#cname',
                        validators: {
                            notEmpty: {
                                message: 'Name field is required and cannot be empty'
                            },
                            regexp: {
                                regexp: /^[a-z A-Z]+$/,
                                message: 'Name only contain alphabets and spaces'
                            },
                        }
                    },
                    fname: {
                        err: '#fname',
                        validators: {
                            notEmpty: {
                                message: 'Father name field is required and cannot be empty'
                            },
                            regexp: {
                                regexp: /^[a-z A-Z]+$/,
                                message: 'Father name field only contain alphabets and spaces'
                            },
                        }
                    },
                    address: {
                        err: '#address',
                        validators: {
                            notEmpty: {
                                message: 'Address field is required and cannot be empty'
                            }
                        }
                    },
                    email: {
                        err: '#email',
                        validators: {
                            notEmpty: {
                                message: 'Email is required and cannot be empty'
                            },
                        }
                    },
                    mobile: {
                        err: '#mobile',
                        validators: {
                            notEmpty: {
                                message: 'Mobile field is required and cannot be empty'
                            },
                            stringLength: {
                                min: 11,
                                max: 11,
                                message: 'The enter a valid mobile number with 11 digits'
                            },
                            regexp: {
                                regexp: /^[0-9]+$/,
                                message: 'Please enter a valid mobile number'
                            },
                        }
                    },
                    file: {
                        err: '#file',
                        validators: {
                            file: {
                                extension: 'jpg,jpe?g,png,pdf,doc,docx,zip,txt,rar,sql',
                                message: 'Please choose a file with jpeg,png,pdf,doc,docx,zip extention.'
                            },
                        },
                    },

                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>