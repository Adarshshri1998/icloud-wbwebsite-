@extends('layouts.app')
@section('title', 'Error')

@section('content')
    <section id="main-home">
        <div class="main-home">
            <div class="main-img-area app">
                <div class="container">
                    <h1>Error</h1>
                </div>
            </div>
        </div>
    </section>


    <section id="category-one">
        <div class="category-one">
            <div class="container contact">
                <div class="submit-area text-center">
                    <h1><i class="fa fa-exclamation-triangle"></i></h1>
                    <h2>Sorry! Page you are looking for doesn't exist</h2>
                </div>
            </div>
        </div>
    </section>
@stop